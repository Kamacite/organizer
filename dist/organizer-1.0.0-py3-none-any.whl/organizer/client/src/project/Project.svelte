<script>
    import ActiveProject from './ActiveProject.svelte';
    import ProjectSelect from './ProjectSelect.svelte';
</script>

<ProjectSelect/>
<ActiveProject/>

<style>
    
</style>